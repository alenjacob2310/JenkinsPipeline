#!/usr/bin/env bash
set -euo pipefail

# Install Java and Maven if missing
if ! command -v java >/dev/null 2>&1 ; then
  sudo apt-get update -y
  sudo apt-get install -y openjdk-17-jdk
fi

if ! command -v mvn >/dev/null 2>&1 ; then
  sudo apt-get update -y
  sudo apt-get install -y maven
fi

# Enable local checkout in Jenkins (lab convenience).
if [ -f /etc/default/jenkins ]; then
  if grep -q 'ALLOW_LOCAL_CHECKOUT' /etc/default/jenkins ; then
    echo "[setup] Jenkins flag already present."
  else
    sudo sed -i 's|JENKINS_JAVA_OPTIONS="\(.*\)"|JENKINS_JAVA_OPTIONS="\1 -Dhudson.plugins.git.GitSCM.ALLOW_LOCAL_CHECKOUT=true"|' /etc/default/jenkins || true
    if ! grep -q 'ALLOW_LOCAL_CHECKOUT' /etc/default/jenkins ; then
      echo 'JENKINS_JAVA_OPTIONS="-Djava.awt.headless=true -Dhudson.plugins.git.GitSCM.ALLOW_LOCAL_CHECKOUT=true"' | sudo tee -a /etc/default/jenkins
    fi
  fi
  sudo systemctl daemon-reload || true
  sudo systemctl restart jenkins || true
else
  echo "[setup] /etc/default/jenkins not found; skipping flag (non-Debian layout?)."
fi

echo "[setup] Done."
