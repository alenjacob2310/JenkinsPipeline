#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
WORK="$BASE_DIR/Web_application"
BARE="$BASE_DIR/Web_application_bare.git"

if [ ! -d "$WORK/.git" ]; then
  echo "Initialize working repo first:"
  echo "  cd $WORK && git init && git add . && git commit -m 'initial'"
  exit 1
fi

if [ -d "$BARE" ]; then
  echo "[info] Bare repo already exists at $BARE"
else
  git init --bare "$BARE"
fi

cd "$WORK"
if git remote get-url bare >/dev/null 2>&1; then
  echo "[info] remote 'bare' already present."
else
  git remote add bare "$BARE"
fi

# Try pushing to main, or master fallback
git push bare HEAD:main || git push bare HEAD:master

echo
echo "Use this Repository URL in Jenkins (SCM → Git):"
echo "  file://$BARE"
