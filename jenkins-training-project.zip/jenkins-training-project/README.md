
# Jenkins Pipeline – Software Engineering (Hands‑On)

A ready-made training project that matches the lab scenario:
- Local Git repo **Web_application** (Maven web app, packages to WAR)
- Jenkins job **Deployment_pipeline**
- Two paths: Freestyle job *or* Declarative Pipeline with **Jenkinsfile**

## Quick start (Ubuntu/Debian style Jenkins)

```bash
# 1) Place the project somewhere accessible to Jenkins
unzip jenkins-training-project.zip -d $HOME/Desktop/Project/
cd $HOME/Desktop/Project/jenkins-training-project

# 2) Prepare the local repo (as in the lab)
cd Web_application
git init
git add .
git commit -m "initial"
cd ..

# Optional: also create a bare repo and point Jenkins to file:///... for extra safety
scripts/make_bare_repo.sh

# 3) Run setup (installs Maven/Java if missing, restarts Jenkins, enables local checkout)
sudo bash scripts/setup.sh

# 4) Jenkins
# - Create Freestyle job named: Deployment_pipeline
# - SCM Repository URL:  /home/labuser/Desktop/Project/jenkins-training-project/Web_application
# - Build step: Invoke top-level Maven targets -> Goals: clean compile package
# Build → expect BUILD SUCCESS and a WAR under Web_application/target/
```

## Pipeline option

Import/commit **Jenkinsfile** from the project root into a remote/bare repo and create a *Pipeline* job with "Pipeline script from SCM".
Stages:
1. Checkout
2. Build (Maven)
3. Test (JUnit)
4. Package (WAR)
5. Archive artifacts

## Intentional failure toggles (for practice)
- Break the unit test: set `EXPECTED=2` in `SampleTest.java`.
- Break compilation: change Java version in `pom.xml` to 21 while toolchain is 17.
- Break packaging: change packaging from `war` to `jar`.

## Contents
- Web_application/ … Maven web app with `pom.xml`, `index.jsp`, `HelloServlet`, `web.xml`, and a JUnit test
- Jenkinsfile … Declarative pipeline using Maven
- scripts/setup.sh … Installs Maven, OpenJDK, and enables local Git checkout in Jenkins
- scripts/make_bare_repo.sh … Converts the working repo to a local `*.git` bare repo and prints the `file:///` URL
